# Commerce IQ — E-commerce Power BI report

Four native Power BI report pages based on the supplied e-commerce ELT sample dataset: executive sales, revenue trends, product performance, and customer insights/orders.

## Open and save

Extract the full archive, open `CommerceIQ.pbip` in current Power BI Desktop on Windows, choose **Home > Refresh**, and use **File > Save as > Power BI file (.pbix)**. No external file path, database, or credentials are needed: the sample snapshot is embedded in the Power Query partitions. Desktop may require enabling the PBIP and PBIR preview options and restarting.

**Validation scope:** programmatically authored PBIP/PBIR report and TMSL model. Data totals and JSON schemas are checked where documented schemas are available. This environment cannot run Power BI Desktop, execute DAX/M, render the report, or produce a binary PBIX. Final open/refresh/render validation remains required; this is not represented as a Desktop-tested production artifact.

## Report

- Executive Sales Summary: four KPI cards, revenue trend, state sales.
- Revenue Trends: revenue area chart, monthly orders and AOV charts.
- Product Performance: top ten revenue ranks, category donut, searchable product slicer and product table.
- Customer Insights & Orders: customer search slicer, sortable customer table, value tiers and recent orders.
- Date, state and category slicers are synchronized across all pages. Native chart cross-filtering is enabled. Native visual menu exports apply in Desktop/Service where supported.

## Data model

`Sales` contains eligible order lines and joins many-to-one to `Products`, `Customers` and `Calendar`. All relationships filter from the dimension to Sales. Currency uses fixed decimal values. Dates have a dedicated daily calendar; year-month is sorted using a numeric month key. Twelve explicit DAX measures are included.

Revenue is net merchandise sales after discounts; shipping and tax are excluded. Cancelled/refunded orders are excluded, while completed/shipped/processing orders are included, matching the source pipeline. Orders and customers are distinct counts. AOV is revenue divided by distinct orders. Customer lifetime value removes calendar and product filters while preserving the customer. It covers the available snapshot, not history outside the source dataset. Top ten uses dense rank and may show tied products.

The product/customer marts use aggregate outputs with different column names. This report derives equivalent metrics from `order_detail.csv` so state, category and date filters remain consistent and daily customer counts are never incorrectly summed. Source product `total_revenue` is net, not gross; gross revenue is calculated separately from gross_sales.

## GitHub

Upload the PBIP file, both item folders, README and measure definitions together. PBIP is text-based native Power BI source suitable for version control. After validating in Desktop, you can additionally upload the saved PBIX and genuine report screenshots. Do not upload only the small PBIP pointer file.

## Refreshing the sample

This release includes the original generated sample snapshot inside the model. Home > Refresh reloads that snapshot; it does not run the upstream pipeline or fetch new transactions. To connect live pipeline exports later, replace each embedded Power Query source while retaining the table/column names and types. The original pipeline archive is not modified.

## Microsoft references

- [Power BI projects and saving PBIP as PBIX](https://learn.microsoft.com/en-us/power-bi/developer/projects/projects-overview)
- [PBIR report definitions](https://learn.microsoft.com/en-us/power-bi/developer/projects/projects-report)
- [Semantic model definitions](https://learn.microsoft.com/en-us/power-bi/developer/projects/projects-dataset)
